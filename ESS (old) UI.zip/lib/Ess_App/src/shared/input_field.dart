import 'package:ess/Ess_App/src/base/utils/utils.dart';
import 'package:ess/Ess_App/src/shared/spacing.dart';
import 'package:ess/Ess_App/src/styles/app_colors.dart';
import 'package:ess/Ess_App/src/styles/text_theme.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_multi_formatter/flutter_multi_formatter.dart';

// ─────────────────────────────────────────────────────────────────────────────
// MainInputField — modern floating-label input with rounded card look
// ─────────────────────────────────────────────────────────────────────────────
class MainInputField extends StatelessWidget {
  final bool isPassword;
  final String? label;
  final String hint;
  final TextEditingController controller;
  final Function? onTap;
  final TextInputType? inputType;
  final ValueChanged<String>? onChanged;
  final bool isRequired;
  final bool? readOnly;
  final String message;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final double? width;
  final double? height;

  const MainInputField({
    Key? key,
    this.width,
    this.height,
    this.isPassword = false,
    this.label,
    required this.hint,
    required this.controller,
    this.onTap,
    this.inputType,
    this.onChanged,
    this.isRequired = true,
    this.suffixIcon,
    this.prefixIcon,
    required this.message,
    this.readOnly,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) ...[
          Text(label!, style: TextStyling.bold14.copyWith(color: AppColors.darkGrey)),
          const SizedBox(height: 6),
        ],
        Container(
          width: width ?? context.screenSize().width,
          height: height ?? 58,
          decoration: BoxDecoration(
            color: AppColors.inputBg,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.border, width: 1.2),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (prefixIcon != null) ...[prefixIcon!, const SizedBox(width: 10)],
              Expanded(
                child: TextFormField(
                  onTap: onTap != null ? () => onTap!() : null,
                  textInputAction: TextInputAction.next,
                  keyboardType: inputType ?? TextInputType.text,
                  validator: (val) {
                    bool emailValid = true;
                    if (inputType == TextInputType.emailAddress) {
                      emailValid = RegExp(
                          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                          .hasMatch(val!);
                    }
                    return isRequired
                        ? (val!.isEmpty || (emailValid == false))
                        ? message
                        : null
                        : null;
                  },
                  onChanged: onChanged,
                  controller: controller,
                  readOnly:
                  (inputType == TextInputType.datetime) ? true : readOnly ?? false,
                  obscureText: isPassword,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: hint,
                    hintStyle:
                    TextStyling.text14.copyWith(color: AppColors.grey),
                    contentPadding:
                    const EdgeInsets.symmetric(vertical: 16),
                  ),
                  cursorColor: AppColors.primary,
                  cursorHeight: 20,
                  style: TextStyling.text14.copyWith(color: AppColors.black),
                ),
              ),
              if (suffixIcon != null) ...[const SizedBox(width: 4), suffixIcon!],
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SecondInputField — bordered card-style input for forms
// ─────────────────────────────────────────────────────────────────────────────
class SecondInputField extends StatelessWidget {
  final bool isPassword;
  final String? label;
  final String hint;
  final TextEditingController controller;
  final Function? onTap;
  final TextInputType? inputType;
  final ValueChanged<String>? onChanged;
  final bool isRequired;
  final bool? readOnly;
  final String message;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final double? width;
  final double? height;

  const SecondInputField({
    Key? key,
    this.width,
    this.height,
    this.isPassword = false,
    this.label,
    required this.hint,
    required this.controller,
    this.onTap,
    this.inputType,
    this.onChanged,
    this.isRequired = true,
    this.suffixIcon,
    this.prefixIcon,
    required this.message,
    this.readOnly,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) ...[
          Text(label!, style: TextStyling.bold14.copyWith(color: AppColors.darkGrey)),
          const SizedBox(height: 6),
        ],
        Container(
          width: width ?? context.screenSize().width,
          height: height ?? 52,
          decoration: BoxDecoration(
            color: AppColors.cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border, width: 1.2),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (prefixIcon != null) ...[prefixIcon!, const SizedBox(width: 8)],
              Expanded(
                child: TextFormField(
                  onTap: onTap != null ? () => onTap!() : null,
                  textInputAction: TextInputAction.next,
                  keyboardType: inputType ?? TextInputType.text,
                  validator: (val) {
                    bool emailValid = true;
                    if (inputType == TextInputType.emailAddress) {
                      emailValid = RegExp(
                        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+",
                      ).hasMatch(val!);
                    }
                    return isRequired
                        ? (val!.isEmpty || (emailValid == false))
                        ? message
                        : null
                        : null;
                  },
                  onChanged: onChanged,
                  inputFormatters: [
                    if (inputType == TextInputType.phone)
                      MaskedInputFormatter('####-###-####'),
                  ],
                  controller: controller,
                  readOnly:
                  (inputType == TextInputType.datetime) ? true : readOnly ?? false,
                  obscureText: isPassword,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: hint,
                    hintStyle:
                    TextStyling.text14.copyWith(color: AppColors.grey),
                    contentPadding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  cursorColor: AppColors.primary,
                  cursorHeight: 20,
                  style: TextStyling.text14.copyWith(color: AppColors.black),
                ),
              ),
              if (suffixIcon != null) ...[const SizedBox(width: 4), suffixIcon!],
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CustomDropDown / customDropDown — kept as-is for backward compat, restyled
// ─────────────────────────────────────────────────────────────────────────────
class CustomDropDown extends StatelessWidget {
  final String? label;
  final String value;
  final List<DropdownMenuItem<String>> items;
  final ValueChanged<String?> onChanged;

  const CustomDropDown({
    Key? key,
    this.label,
    required this.value,
    required this.items,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) ...[
          Text(label!, style: TextStyling.bold14.copyWith(color: AppColors.darkGrey)),
          const SizedBox(height: 6),
        ],
        Container(
          width: context.screenSize().width,
          height: 52,
          decoration: BoxDecoration(
            color: AppColors.cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border, width: 1.2),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              style: TextStyling.text14.copyWith(color: AppColors.primary),
              value: value,
              icon: Icon(Icons.keyboard_arrow_down_rounded,
                  color: AppColors.primary, size: 20),
              items: items,
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }
}

class customDropDown extends StatelessWidget {
  final String value;
  final List<String> items;
  final ValueChanged<String?> onChanged;

  customDropDown({
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButton<String>(
      value: value,
      items: items
          .map<DropdownMenuItem<String>>(
            (String item) => DropdownMenuItem<String>(
          value: item,
          child: Text(item),
        ),
      )
          .toList(),
      onChanged: onChanged,
    );
  }
}
