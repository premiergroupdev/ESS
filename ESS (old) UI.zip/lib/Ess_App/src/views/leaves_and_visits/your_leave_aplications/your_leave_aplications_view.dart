import 'package:ess/Ess_App/src/shared/loading_indicator.dart';
import 'package:ess/Ess_App/src/shared/spacing.dart';
import 'package:ess/Ess_App/src/shared/top_app_bar.dart';
import 'package:ess/Ess_App/src/styles/app_colors.dart';
import 'package:ess/Ess_App/src/styles/text_theme.dart';
import 'package:ess/Ess_App/src/views/leaves_and_visits/your_leave_aplications/widget/leave_aplications_data_table.dart';
import 'package:ess/Ess_App/src/views/leaves_and_visits/your_leave_aplications/your_leave_aplications_view_model.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class LeaveApplicationsView extends StatelessWidget {
  const LeaveApplicationsView({super.key});

  static const Color _pageBackground = Color(0xFFF6F7FB);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LeaveApplicationsViewModel>.reactive(
      builder: (viewModelContext, model, child) => Scaffold(
        backgroundColor: _pageBackground,
        body: SafeArea(
          // Column + Expanded replaces the old "screen height - 145" hack.
          child: Column(
            children: [
              GeneralAppBar(
                title: "Leave Applications",
                onMenuTap: () {
                  Scaffold.of(context).openDrawer();
                },
                onNotificationTap: () {},
              ),
              const _StatusLegend(),
              Expanded(
                child: model.isBusy
                    ? Center(child: LoadingIndicator())
                    : model.data.isEmpty
                    ? const _EmptyState()
                    : SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                  child: Container(
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.06),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: LeaveApplicationsDataTable(
                      heading: model.heading,
                      data: model.data,
                      onTap: (int index) {
                        var selectedData = model.data[index];
                        showLeaveApplication(context, selectedData);
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      viewModelBuilder: () => LeaveApplicationsViewModel(),
      onModelReady: (model) => model.init(context),
    );
  }

  void showLeaveApplication(
      BuildContext context, LeaveApplicationsTableData data) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: AppColors.white,
          insetPadding: const EdgeInsets.symmetric(horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header: title + close
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        "Leave Details",
                        style: TextStyling.bold20
                            .copyWith(color: AppColors.primary),
                      ),
                    ),
                    InkWell(
                      onTap: () => Navigator.of(dialogContext).pop(),
                      borderRadius: BorderRadius.circular(20),
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: Icon(Icons.close,
                            size: 22, color: Colors.grey.shade600),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                // Status pill
                Container(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: data.statusColor?.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    data.status.toString(),
                    style: TextStyling.bold18
                        .copyWith(color: data.statusColor),
                  ),
                ),
                const SizedBox(height: 20),

                // Details
                _DetailRow(
                  icon: Icons.event_note_outlined,
                  label: "Applied On",
                  value: data.appliedDate,
                ),
                _DetailRow(
                  icon: Icons.play_circle_outline,
                  label: "Leave Start",
                  value: data.startDate,
                ),
                _DetailRow(
                  icon: Icons.stop_circle_outlined,
                  label: "Leave End",
                  value: data.endDate,
                ),
                _DetailRow(
                  icon: Icons.timelapse,
                  label: "Number of Days",
                  value: data.totalDays.toString(),
                ),
                const SizedBox(height: 16),

                // Leave type breakdown
                Row(
                  children: [
                    Expanded(
                        child: _LeaveTypeTile(
                            label: "Sick", value: data.sick.toString())),
                    const SizedBox(width: 10),
                    Expanded(
                        child: _LeaveTypeTile(
                            label: "Casual", value: data.casual.toString())),
                    const SizedBox(width: 10),
                    Expanded(
                        child: _LeaveTypeTile(
                            label: "Annual", value: data.annual.toString())),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Approved / Pending / Rejected legend as small pills.
class _StatusLegend extends StatelessWidget {
  const _StatusLegend();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _LegendChip(title: "Approved", color: Colors.green),
          _LegendChip(title: "Pending", color: Colors.orange),
          _LegendChip(title: "Rejected", color: Colors.red),
        ],
      ),
    );
  }
}

class _LegendChip extends StatelessWidget {
  final String title;
  final Color color;

  const _LegendChip({required this.title, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 10,
            width: 10,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 6),
          Text(title, style: TextStyling.text16.copyWith(color: color)),
        ],
      ),
    );
  }
}

/// One label/value line inside the details dialog.
class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _DetailRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.primary),
          const SizedBox(width: 10),
          Text(
            label,
            style: TextStyling.text16.copyWith(color: Colors.grey.shade600),
          ),
          const Spacer(),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: TextStyling.bold18.copyWith(color: AppColors.secondary),
            ),
          ),
        ],
      ),
    );
  }
}

/// Sick / Casual / Annual count tile.
class _LeaveTypeTile extends StatelessWidget {
  final String label;
  final String value;

  const _LeaveTypeTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.07),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyling.bold20.copyWith(color: AppColors.secondary),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyling.text16.copyWith(color: AppColors.primary),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.event_busy_outlined,
              size: 56, color: Colors.grey.shade400),
          const SizedBox(height: 12),
          Text(
            "No leave applications yet",
            style: TextStyling.text16.copyWith(color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }
}